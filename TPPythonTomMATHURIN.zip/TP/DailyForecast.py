class DailyForecast:
    def __init__(self, date_local):
        self.date_local = date_local
        self.rain_cumul_mm = 0.0
        self.snow_cumul_mm = 0.0
        self.major_transitions_count = 0

    def to_dict(self):
        return {
            "date_local": self.date_local,
            "rain_cumul_mm": round(self.rain_cumul_mm, 1),
            "snow_cumul_mm": round(self.snow_cumul_mm, 1),
            "major_transitions_count": self.major_transitions_count,
        }
