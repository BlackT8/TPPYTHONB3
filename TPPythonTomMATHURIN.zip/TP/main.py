import sys
from loguru import logger
import WeatherAnalysis as wa

# Loguru setup
logger.add("weather_analysis{time}.log")
logger.add(sys.stderr, format="{time} {level} {message}", level="INFO")


def check_input(city, country_code):
    if not city or not country_code:
        logger.error("ERROR: City and country code cannot be empty.")
        return False
    if len(country_code) != 2 or not country_code.isalpha():
        logger.error("ERROR: Country code lenght must be equal to 2")
        return False
    return True


def main():
    input_city = input("Enter the city name: ")
    input_country_code = input("Enter the country code: ")

    if not check_input(input_city, input_country_code):
        return
    analyzer = wa.WeatherAnalysis(input_city, input_country_code)
    analyzer.generate_report()


if __name__ == "__main__":
    main()
