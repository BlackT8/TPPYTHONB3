import requests
import json
import os
from loguru import logger
import DailyForecast as df

API_KEY = "be83acfe7b846fc5480004ffc039c49d"
URL_API = "https://api.openweathermap.org/data/2.5/forecast"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CERT_PATH = os.path.join(BASE_DIR, "airbus-ca.crt")
# Comment out line 41 and uncomment line 42 to use the certificate


class WeatherAnalysis:
    def __init__(self, city, country_code):
        self.city = city
        self.country_code = country_code
        self.data = None
        self.forecast_list = []
        self.city_info = {}

        self.total_rain_period_mm = 0.0
        self.total_snow_period_mm = 0.0
        self.max_humidity_period = 0
        self.daily_details = []  # List of DailyForecast

        logger.info(
            f"Analysis initialized for {self.city}, \
                    {self.country_code}"
        )

    @logger.catch
    def get_data(self):
        params = {
            "q": f"{self.city},{self.country_code}",
            "appid": API_KEY,
            "units": "metric",
        }
        logger.info("Request to OpenWeather API")
        try:
            response = requests.get(URL_API, params=params)
            # response = requests.get(URL_API, params=params, verify=CERT_PATH)
            response.raise_for_status()  # Exception for 4xx/5xx status code
            self.data = response.json()

            # Check if status code is OK
            if self.data.get("cod") != "200":
                logger.error(
                    f"ERROR: Code {self.data.get('cod')}. \
                             Message: {self.data.get('message')}"
                )
                return False
            self.forecast_list = self.data.get("list", [])
            self.city_info = self.data.get("city", {})

            # Save raw data
            with open("brut_forecast.json", "w") as jf:
                json.dump(self.data, jf, indent=2)
            logger.info("Data saved to 'brut_forecast.json")
            return True

        except requests.exceptions.RequestException as e:
            logger.critical(f"ERROR HTTP: {e}")
            return False

    def analyse_forecast(self):
        if not self.forecast_list:
            logger.warning("No data available.")
            return

        # Store DailyForecast, date:element
        daily_results_map = {}

        # Track previous state for transition detection
        previous_weather_main = None
        previous_temp = None

        for i, elt in enumerate(self.forecast_list):
            date_local = elt.get("dt_txt")[:10]
            rain_3h = elt.get("rain", {}).get("3h", 0.0)
            snow_3h = elt.get("snow", {}).get("3h", 0.0)
            current_weather_main = elt.get("weather", [{}])[0].get("main", "")
            current_temp = elt.get("main", {}).get("temp", None)
            current_humidity = elt.get("main", {}).get("humidity", 0)

            if date_local not in daily_results_map:
                daily_results_map[date_local] = df.DailyForecast(date_local)

            current_day_obj = daily_results_map[date_local]
            current_day_obj.rain_cumul_mm += rain_3h
            current_day_obj.snow_cumul_mm += snow_3h

            self.total_rain_period_mm += rain_3h
            self.total_snow_period_mm += snow_3h
            self.max_humidity_period = max(self.max_humidity_period, current_humidity)

            if i > 0 and previous_temp is not None and current_temp is not None:
                weather_changed = current_weather_main != previous_weather_main
                temp_change_major = abs(current_temp - previous_temp) > 3.0

                # Major transition = weather AND major temp. change
                if weather_changed and temp_change_major:
                    current_day_obj.major_transitions_count += 1

            previous_weather_main = current_weather_main
            previous_temp = current_temp
        logger.info("Analysis finished")
        self.daily_details = [df.to_dict() for df in daily_results_map.values()]

    def generate_report(self):
        if not self.get_data():
            return
        if not self.forecast_list:
            logger.critical("No data in the forecast list.")
            return
        self.analyse_forecast()

        result = {
            "forecast_location_name": self.city_info.get("name", self.city),
            "country_code": self.city_info.get("country", self.country_code),
            "total_rain_period_mm": round(self.total_rain_period_mm, 1),
            "total_snow_period_mm": round(self.total_snow_period_mm, 1),
            "max_humidity_period": self.max_humidity_period,
            "forecast_details": self.daily_details,
        }

        city_name = self.city_info.get("name", self.city)
        output_filename = f"weather_report_{city_name}_{self.country_code}.json"

        with open(output_filename, "w") as outfile:
            json.dump(result, outfile, indent=4)
